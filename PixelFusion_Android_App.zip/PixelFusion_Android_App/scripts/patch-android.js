// Run after `npx cap add android`: installs PixelFusion launcher icons + dark system bars.
const fs = require('fs'), path = require('path');
const root = path.join(__dirname, '..');
const res = path.join(root, 'android', 'app', 'src', 'main', 'res');
if (!fs.existsSync(res)) { console.error('android/ not found - run `npx cap add android` first'); process.exit(1); }

function copyDir(src, dst) {
  fs.mkdirSync(dst, { recursive: true });
  for (const e of fs.readdirSync(src, { withFileTypes: true })) {
    const s = path.join(src, e.name), d = path.join(dst, e.name);
    e.isDirectory() ? copyDir(s, d) : fs.copyFileSync(s, d);
  }
}
// 1) icons
copyDir(path.join(root, 'android-res'), res);
const any26 = path.join(res, 'mipmap-anydpi-v26');
fs.mkdirSync(any26, { recursive: true });
const adaptive = '<?xml version="1.0" encoding="utf-8"?>\n<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">\n  <background android:drawable="@mipmap/pf_bg"/>\n  <foreground android:drawable="@mipmap/pf_fg"/>\n</adaptive-icon>\n';
fs.writeFileSync(path.join(any26, 'ic_launcher.xml'), adaptive);
fs.writeFileSync(path.join(any26, 'ic_launcher_round.xml'), adaptive);
// 2) system bar colours
const styles = path.join(res, 'values', 'styles.xml');
if (fs.existsSync(styles)) {
  let x = fs.readFileSync(styles, 'utf8');
  if (!x.includes('pfBars')) {
    x = x.replace(/(<style name="AppTheme\.NoActionBar"[^>]*>)/, '$1\n        <!-- pfBars -->\n        <item name="android:statusBarColor">#10111A</item>\n        <item name="android:navigationBarColor">#10111A</item>');
    fs.writeFileSync(styles, x);
  }
}
console.log('PixelFusion Android patch applied.');
