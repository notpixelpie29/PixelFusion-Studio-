PixelFusion Studio - Android APP (APK) banane ka tareeka
=========================================================

Ye project asli Android app (APK) banata hai. Editor app ke andar bundle hota hai,
isliye browser/link ki zarurat nahi - home screen se app ki tarah khulta hai.

TARIKA 1 - GitHub se (PC/Android Studio ke bina, sabse aasan)
1. github.com par free account banao, "New repository" banao.
2. Is poore folder ki saari files (www, scripts, android-res, .github, package.json,
   capacitor.config.json, .gitignore) repo me upload karo ("Add file > Upload files").
   NOTE: ".github" folder bhi upload hona chahiye.
3. Repo me "Actions" tab > "Build PixelFusion APK" > "Run workflow".
4. 4-6 minute baad run kholo > neeche "Artifacts" me "PixelFusion-Studio-APK" download karo.
5. Zip ke andar app-debug.apk hai. Phone me install karo
   (Settings me "Install unknown apps" allow karna padega).

TARIKA 2 - Apne PC par (Node 20 + Java 17 + Android Studio/SDK chahiye)
   npm install
   npx cap add android
   node scripts/patch-android.js
   npx cap sync android
   cd android && ./gradlew assembleDebug
   APK: android/app/build/outputs/apk/debug/app-debug.apk
   (ya "npx cap open android" se Android Studio me kholo)

APP ME KYA ALAG HAI
- Landscape/portrait dono me chalta hai, rotate karne par project reload nahi hota.
- Export (video .webm / thumbnail .png) ab app me "Save/Share" sheet kholta hai -
  wahin se Files, Drive ya WhatsApp me save/share kar sakte ho.
- Logo = PixelFusion_Logo_1024.png (launcher icon + app ke andar).

PLAY STORE ke liye signed release (AAB) chahiye hoga - alag se keystore banana padta hai.
Batao to wo bhi set kar dunga.

Cloud sign-in (Supabase) ke liye internet chahiye; baaki editing offline chalti hai
(sirf online SFX/CDN items ko internet lagta hai).
