/* PixelFusion native bridge: makes "download" (blob/data) exports work inside the Android app
   by saving to app cache and opening the Android share/save sheet. No effect in a normal browser. */
(function () {
  'use strict';
  var C = window.Capacitor;
  if (!C || !C.isNativePlatform || !C.isNativePlatform()) return;
  document.documentElement.classList.add('pf-native');

  function note(msg) { try { if (typeof window.toast === 'function') window.toast(msg); } catch (e) {} }
  function b64(blob) {
    return new Promise(function (res, rej) {
      var r = new FileReader();
      r.onload = function () { res(String(r.result).split(',')[1] || ''); };
      r.onerror = function () { rej(r.error); };
      r.readAsDataURL(blob);
    });
  }
  async function saveAndShare(url, rawName) {
    var P = C.Plugins || {}, FS = P.Filesystem, SH = P.Share;
    if (!FS || !SH) { note('Save plugin missing - rebuild the app.'); return; }
    var name = (rawName || 'pixelfusion-export').replace(/[^\w.\-]+/g, '_');
    var blob = await (await fetch(url)).blob();
    var path = 'exports/' + Date.now() + '_' + name;
    var CHUNK = 3 * 1024 * 1024; // multiple of 3 => clean base64 joins
    note('Preparing ' + name + '...');
    for (var off = 0, first = true; off < blob.size || first; off += CHUNK) {
      var data = await b64(blob.slice(off, off + CHUNK));
      if (first) { await FS.writeFile({ path: path, data: data, directory: 'CACHE', recursive: true }); first = false; }
      else { await FS.appendFile({ path: path, data: data, directory: 'CACHE' }); }
      if (blob.size === 0) break;
    }
    var uri = (await FS.getUri({ path: path, directory: 'CACHE' })).uri;
    await SH.share({ title: name, url: uri, dialogTitle: 'Save or share ' + name });
  }

  var origClick = HTMLAnchorElement.prototype.click;
  HTMLAnchorElement.prototype.click = function () {
    var href = this.href || '';
    if (this.hasAttribute('download') && /^(blob:|data:)/.test(href)) {
      saveAndShare(href, this.getAttribute('download')).catch(function (e) {
        console.error('Native save failed', e);
        note('Could not save file: ' + (e && e.message ? e.message : e));
      });
      return;
    }
    return origClick.apply(this, arguments);
  };
})();
